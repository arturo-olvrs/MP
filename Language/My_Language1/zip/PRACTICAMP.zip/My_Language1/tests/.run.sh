touch tests//.timeout
CMD="valgrind --leak-check=full /home/arturoolvrs/Desktop/RepositorioMP/Language/My_Language1/dist/Debug/GNU-Linux/my_language1  < data/SimpleTextbigrams.txt 1> tests//.out7 2>&1"
eval $CMD
rm tests//.timeout
